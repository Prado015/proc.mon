from sqlalchemy.orm import Session
from app.db.database import engine
from app.models.base import BaseModel
from app.models import user, requisition, supplier, purchase_order, staff, audit_log
from app.crud import user as user_crud
from app.schemas.user import UserCreate
from app.models.user import UserRole

def init_db(db: Session) -> None:
    # Create all tables
    BaseModel.metadata.create_all(bind=engine)
    
    # Create default admin user
    admin_user = user_crud.get_by_email(db, email="admin@procurement.com")
    if not admin_user:
        user_in = UserCreate(
            email="admin@procurement.com",
            password="admin123",
            full_name="System Administrator",
            role=UserRole.ADMIN,
            department="IT"
        )
        admin_user = user_crud.create(db, obj_in=user_in)
        print(f"Created admin user: {admin_user.email}")