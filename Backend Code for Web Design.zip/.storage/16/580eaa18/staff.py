from sqlalchemy import Column, String, Enum as SQLEnum
from enum import Enum
from .base import BaseModel

class StaffPosition(str, Enum):
    PROCUREMENT_OFFICER = "procurement_officer"
    ACCOUNTABLE_OFFICER = "accountable_officer"
    RECEIVING_OFFICER = "receiving_officer"
    DEPARTMENT_HEAD = "department_head"
    ADMIN = "admin"
    STAFF = "staff"

class Staff(BaseModel):
    __tablename__ = "staff"
    
    staff_id = Column(String, unique=True, nullable=False, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    phone = Column(String, nullable=True)
    department = Column(String, nullable=False)
    position = Column(SQLEnum(StaffPosition), nullable=False)
    is_active = Column(String, default="active")  # active, inactive