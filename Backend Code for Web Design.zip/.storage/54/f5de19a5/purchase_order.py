from sqlalchemy import Column, String, DateTime, Text, ForeignKey, Enum as SQLEnum, Numeric
from sqlalchemy.orm import relationship
from enum import Enum
from .base import BaseModel

class PurchaseOrderStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    ORDERED = "ordered"
    DELIVERED = "delivered"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class ProcurementMode(str, Enum):
    SHOPPING = "shopping"
    SMALL_VALUE = "small_value"
    PUBLIC_BIDDING = "public_bidding"
    NEGOTIATED = "negotiated"
    DIRECT_CONTRACTING = "direct_contracting"

class PurchaseOrder(BaseModel):
    __tablename__ = "purchase_orders"
    
    po_number = Column(String, unique=True, nullable=False, index=True)
    requisition_id = Column(String, ForeignKey("requisitions.id"), nullable=False)
    supplier_id = Column(String, ForeignKey("suppliers.id"), nullable=False)
    supplier_name = Column(String, nullable=False)  # For manual entries
    department = Column(String, nullable=False)
    procurement_mode = Column(SQLEnum(ProcurementMode), nullable=False)
    date_ordered = Column(DateTime, nullable=True)
    date_needed = Column(DateTime, nullable=False)
    estimated_delivery = Column(DateTime, nullable=True)
    date_delivered = Column(DateTime, nullable=True)
    receiving_officer = Column(String, nullable=False)
    status = Column(SQLEnum(PurchaseOrderStatus), default=PurchaseOrderStatus.PENDING)
    notes = Column(Text, nullable=True)
    total_amount = Column(Numeric(10, 2), nullable=True)
    
    # Relationships
    requisition = relationship("Requisition", back_populates="purchase_orders")
    supplier = relationship("Supplier", back_populates="purchase_orders")
    delivery_dates = relationship("DeliveryDate", back_populates="purchase_order", cascade="all, delete-orphan")

class DeliveryDate(BaseModel):
    __tablename__ = "delivery_dates"
    
    purchase_order_id = Column(String, ForeignKey("purchase_orders.id"), nullable=False)
    delivery_date = Column(DateTime, nullable=False)
    notes = Column(Text, nullable=True)
    
    # Relationships
    purchase_order = relationship("PurchaseOrder", back_populates="delivery_dates")