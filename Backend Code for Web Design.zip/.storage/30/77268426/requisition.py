from typing import List, Optional
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.requisition import Requisition, RequisitionItem
from app.schemas.requisition import RequisitionCreate, RequisitionUpdate

class CRUDRequisition(CRUDBase[Requisition, RequisitionCreate, RequisitionUpdate]):
    def create_with_items(self, db: Session, *, obj_in: RequisitionCreate) -> Requisition:
        # Create requisition
        requisition_data = obj_in.dict(exclude={"items"})
        db_requisition = Requisition(**requisition_data)
        db.add(db_requisition)
        db.flush()  # To get the ID
        
        # Create items
        for item_data in obj_in.items:
            db_item = RequisitionItem(**item_data.dict(), requisition_id=db_requisition.id)
            db.add(db_item)
        
        db.commit()
        db.refresh(db_requisition)
        return db_requisition
    
    def get_by_req_number(self, db: Session, *, req_number: str) -> Optional[Requisition]:
        return db.query(Requisition).filter(Requisition.req_number == req_number).first()
    
    def search_requisitions(self, db: Session, *, query: str, skip: int = 0, limit: int = 100) -> List[Requisition]:
        return db.query(Requisition).filter(
            Requisition.req_number.contains(query) |
            Requisition.office.contains(query) |
            Requisition.purpose.contains(query) |
            Requisition.accountable_officer.contains(query)
        ).offset(skip).limit(limit).all()

requisition = CRUDRequisition(Requisition)