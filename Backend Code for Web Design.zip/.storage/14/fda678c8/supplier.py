from sqlalchemy import Column, String, Text, Enum as SQLEnum
from sqlalchemy.orm import relationship
from enum import Enum
from .base import BaseModel

class SupplierStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"

class SupplierCategory(str, Enum):
    OFFICE_SUPPLIES = "office_supplies"
    IT_EQUIPMENT = "it_equipment"
    FURNITURE = "furniture"
    MAINTENANCE = "maintenance"
    MEDICAL = "medical"
    FOOD_CATERING = "food_catering"
    CONSTRUCTION = "construction"
    OTHER = "other"

class Supplier(BaseModel):
    __tablename__ = "suppliers"
    
    supplier_id = Column(String, unique=True, nullable=False, index=True)
    company_name = Column(String, nullable=False)
    contact_person = Column(String, nullable=False)
    email = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    tin = Column(String, nullable=True)
    vat = Column(String, nullable=True)
    category = Column(SQLEnum(SupplierCategory), nullable=False)
    status = Column(SQLEnum(SupplierStatus), default=SupplierStatus.ACTIVE)
    address = Column(Text, nullable=True)
    notes = Column(Text, nullable=True)
    
    # Relationships
    purchase_orders = relationship("PurchaseOrder", back_populates="supplier")