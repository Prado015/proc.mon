from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api.deps import get_db, get_current_active_user
from app.crud import purchase_order
from app.schemas.purchase_order import PurchaseOrder, PurchaseOrderCreate, PurchaseOrderUpdate
from app.models.user import User

router = APIRouter()

@router.get("/", response_model=List[PurchaseOrder])
def read_purchase_orders(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    purchase_orders = purchase_order.get_multi(db, skip=skip, limit=limit)
    return purchase_orders

@router.post("/", response_model=PurchaseOrder)
def create_purchase_order(
    *,
    db: Session = Depends(get_db),
    purchase_order_in: PurchaseOrderCreate,
    current_user: User = Depends(get_current_active_user),
):
    purchase_order_obj = purchase_order.create_with_delivery_dates(db=db, obj_in=purchase_order_in)
    return purchase_order_obj

@router.get("/search", response_model=List[PurchaseOrder])
def search_purchase_orders(
    query: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    purchase_orders = purchase_order.search_purchase_orders(db, query=query, skip=skip, limit=limit)
    return purchase_orders

@router.get("/{purchase_order_id}", response_model=PurchaseOrder)
def read_purchase_order(
    *,
    db: Session = Depends(get_db),
    purchase_order_id: str,
    current_user: User = Depends(get_current_active_user),
):
    purchase_order_obj = purchase_order.get(db=db, id=purchase_order_id)
    if not purchase_order_obj:
        raise HTTPException(status_code=404, detail="Purchase Order not found")
    return purchase_order_obj

@router.put("/{purchase_order_id}", response_model=PurchaseOrder)
def update_purchase_order(
    *,
    db: Session = Depends(get_db),
    purchase_order_id: str,
    purchase_order_in: PurchaseOrderUpdate,
    current_user: User = Depends(get_current_active_user),
):
    purchase_order_obj = purchase_order.get(db=db, id=purchase_order_id)
    if not purchase_order_obj:
        raise HTTPException(status_code=404, detail="Purchase Order not found")
    purchase_order_obj = purchase_order.update(db=db, db_obj=purchase_order_obj, obj_in=purchase_order_in)
    return purchase_order_obj

@router.delete("/{purchase_order_id}")
def delete_purchase_order(
    *,
    db: Session = Depends(get_db),
    purchase_order_id: str,
    current_user: User = Depends(get_current_active_user),
):
    purchase_order_obj = purchase_order.get(db=db, id=purchase_order_id)
    if not purchase_order_obj:
        raise HTTPException(status_code=404, detail="Purchase Order not found")
    purchase_order.remove(db=db, id=purchase_order_id)
    return {"message": "Purchase Order deleted successfully"}