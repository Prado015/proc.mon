from fastapi import APIRouter
from app.api.api_v1.endpoints import users, auth, requisitions, suppliers, purchase_orders, staff, audit_logs, dashboard

api_router = APIRouter()
api_router.include_router(auth.router, prefix="/auth", tags=["authentication"])
api_router.include_router(users.router, prefix="/users", tags=["users"])
api_router.include_router(requisitions.router, prefix="/requisitions", tags=["requisitions"])
api_router.include_router(suppliers.router, prefix="/suppliers", tags=["suppliers"])
api_router.include_router(purchase_orders.router, prefix="/purchase-orders", tags=["purchase_orders"])
api_router.include_router(staff.router, prefix="/staff", tags=["staff"])
api_router.include_router(audit_logs.router, prefix="/audit-logs", tags=["audit_logs"])
api_router.include_router(dashboard.router, prefix="/dashboard", tags=["dashboard"])