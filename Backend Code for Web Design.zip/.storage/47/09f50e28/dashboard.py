from typing import Dict, Any, List
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from datetime import datetime, timedelta
from app.api.deps import get_db, get_current_active_user
from app.models.user import User
from app.models.requisition import Requisition, RequisitionStatus, RequisitionType
from app.models.supplier import Supplier, SupplierStatus
from app.models.purchase_order import PurchaseOrder, PurchaseOrderStatus

router = APIRouter()

@router.get("/stats", response_model=Dict[str, Any])
def get_dashboard_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    # Get basic counts
    total_requisitions = db.query(Requisition).count()
    pending_requisitions = db.query(Requisition).filter(Requisition.status == RequisitionStatus.PENDING).count()
    completed_requisitions = db.query(Requisition).filter(Requisition.status == RequisitionStatus.COMPLETED).count()
    
    total_suppliers = db.query(Supplier).count()
    active_suppliers = db.query(Supplier).filter(Supplier.status == SupplierStatus.ACTIVE).count()
    
    total_purchase_orders = db.query(PurchaseOrder).count()
    pending_deliveries = db.query(PurchaseOrder).filter(PurchaseOrder.status.in_([PurchaseOrderStatus.ORDERED, PurchaseOrderStatus.APPROVED])).count()
    delivered_orders = db.query(PurchaseOrder).filter(PurchaseOrder.status == PurchaseOrderStatus.DELIVERED).count()
    
    # Calculate monthly requisitions for current year
    current_year = datetime.now().year
    monthly_requisitions = []
    for month in range(1, 13):
        count = db.query(Requisition).filter(
            and_(
                func.extract('year', Requisition.created_at) == current_year,
                func.extract('month', Requisition.created_at) == month
            )
        ).count()
        monthly_requisitions.append(count)
    
    # Get recent requisitions
    recent_requisitions = db.query(Requisition).order_by(Requisition.created_at.desc()).limit(5).all()
    
    # Calculate delivery performance
    on_time_deliveries = db.query(PurchaseOrder).filter(
        and_(
            PurchaseOrder.date_delivered.isnot(None),
            PurchaseOrder.date_delivered <= PurchaseOrder.date_needed
        )
    ).count()
    
    total_deliveries = db.query(PurchaseOrder).filter(PurchaseOrder.date_delivered.isnot(None)).count()
    on_time_percentage = (on_time_deliveries / total_deliveries * 100) if total_deliveries > 0 else 0
    
    return {
        "total_requisitions": total_requisitions,
        "pending_requisitions": pending_requisitions,
        "completed_requisitions": completed_requisitions,
        "total_suppliers": total_suppliers,
        "active_suppliers": active_suppliers,
        "total_purchase_orders": total_purchase_orders,
        "pending_deliveries": pending_deliveries,
        "delivered_orders": delivered_orders,
        "monthly_requisitions": monthly_requisitions,
        "recent_requisitions": [
            {
                "id": req.id,
                "req_number": req.req_number,
                "office": req.office,
                "status": req.status,
                "created_at": req.created_at
            } for req in recent_requisitions
        ],
        "on_time_percentage": round(on_time_percentage, 2)
    }

@router.get("/requisitions-by-type")
def get_requisitions_by_type(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    consumable_count = db.query(Requisition).filter(Requisition.req_type == RequisitionType.CONSUMABLE).count()
    non_consumable_count = db.query(Requisition).filter(Requisition.req_type == RequisitionType.NON_CONSUMABLE).count()
    
    return {
        "consumable": consumable_count,
        "non_consumable": non_consumable_count
    }

@router.get("/supplier-performance")
def get_supplier_performance(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    # Get supplier performance data
    supplier_stats = db.query(
        Supplier.company_name,
        func.count(PurchaseOrder.id).label('total_orders'),
        func.count(
            func.nullif(PurchaseOrder.date_delivered <= PurchaseOrder.date_needed, False)
        ).label('on_time_deliveries')
    ).join(PurchaseOrder).group_by(Supplier.id, Supplier.company_name).all()
    
    performance_data = []
    for supplier_name, total_orders, on_time_deliveries in supplier_stats:
        on_time_rate = (on_time_deliveries / total_orders * 100) if total_orders > 0 else 0
        performance_data.append({
            "supplier": supplier_name,
            "total_orders": total_orders,
            "on_time_deliveries": on_time_deliveries,
            "on_time_rate": round(on_time_rate, 2)
        })
    
    return performance_data

@router.get("/department-metrics")
def get_department_metrics(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    # Get requisitions by department/office
    department_stats = db.query(
        Requisition.office,
        func.count(Requisition.id).label('total_requisitions'),
        func.count(func.nullif(Requisition.status == RequisitionStatus.COMPLETED, False)).label('completed')
    ).group_by(Requisition.office).all()
    
    metrics = []
    for office, total, completed in department_stats:
        completion_rate = (completed / total * 100) if total > 0 else 0
        metrics.append({
            "department": office,
            "total_requisitions": total,
            "completed": completed,
            "completion_rate": round(completion_rate, 2)
        })
    
    return metrics