from pydantic import BaseModel, validator
from typing import List, Optional
from datetime import datetime
from decimal import Decimal
from app.models.purchase_order import PurchaseOrderStatus, ProcurementMode

class DeliveryDateBase(BaseModel):
    delivery_date: datetime
    notes: Optional[str] = None

class DeliveryDateCreate(DeliveryDateBase):
    pass

class DeliveryDate(DeliveryDateBase):
    id: str
    purchase_order_id: str
    created_at: datetime
    
    class Config:
        orm_mode = True

class PurchaseOrderBase(BaseModel):
    po_number: Optional[str] = None
    requisition_id: str
    supplier_id: Optional[str] = None
    supplier_name: str
    department: str
    procurement_mode: ProcurementMode
    date_ordered: Optional[datetime] = None
    date_needed: datetime
    estimated_delivery: Optional[datetime] = None
    date_delivered: Optional[datetime] = None
    receiving_officer: str
    status: PurchaseOrderStatus = PurchaseOrderStatus.PENDING
    notes: Optional[str] = None
    total_amount: Optional[Decimal] = None

class PurchaseOrderCreate(PurchaseOrderBase):
    delivery_dates: List[DeliveryDateCreate] = []
    
    @validator('po_number', pre=True, always=True)
    def generate_po_number(cls, v):
        if not v:
            import time
            return f"PO-{int(time.time())}"
        return v

class PurchaseOrderUpdate(BaseModel):
    supplier_id: Optional[str] = None
    supplier_name: Optional[str] = None
    department: Optional[str] = None
    procurement_mode: Optional[ProcurementMode] = None
    date_ordered: Optional[datetime] = None
    date_needed: Optional[datetime] = None
    estimated_delivery: Optional[datetime] = None
    date_delivered: Optional[datetime] = None
    receiving_officer: Optional[str] = None
    status: Optional[PurchaseOrderStatus] = None
    notes: Optional[str] = None
    total_amount: Optional[Decimal] = None

class PurchaseOrder(PurchaseOrderBase):
    id: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    delivery_dates: List[DeliveryDate] = []
    
    class Config:
        orm_mode = True