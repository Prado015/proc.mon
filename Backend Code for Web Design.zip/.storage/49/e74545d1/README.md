# UB Procurement System Backend

A comprehensive backend API for the University of Bohol Procurement Requisition & Purchase Order Monitoring System.

## Features

- **Authentication & Authorization**: JWT-based authentication with role-based access control
- **Requisition Management**: Create, track, and manage procurement requisitions
- **Supplier Management**: Maintain supplier database with categories and status tracking
- **Purchase Order Management**: Handle PO creation, tracking, and delivery management
- **Staff Management**: Manage staff members and their roles
- **Dashboard Analytics**: Real-time statistics and performance metrics
- **Audit Logging**: Complete audit trail for all system activities

## API Endpoints

### Authentication
- `POST /api/v1/auth/login` - User login

### Requisitions
- `GET /api/v1/requisitions/` - List all requisitions
- `POST /api/v1/requisitions/` - Create new requisition
- `GET /api/v1/requisitions/search?query=` - Search requisitions
- `GET /api/v1/requisitions/{id}` - Get requisition details
- `PUT /api/v1/requisitions/{id}` - Update requisition
- `DELETE /api/v1/requisitions/{id}` - Delete requisition

### Suppliers
- `GET /api/v1/suppliers/` - List all suppliers
- `GET /api/v1/suppliers/active` - List active suppliers
- `POST /api/v1/suppliers/` - Create new supplier
- `GET /api/v1/suppliers/search?query=` - Search suppliers
- `GET /api/v1/suppliers/{id}` - Get supplier details
- `PUT /api/v1/suppliers/{id}` - Update supplier
- `DELETE /api/v1/suppliers/{id}` - Delete supplier

### Purchase Orders
- `GET /api/v1/purchase-orders/` - List all purchase orders
- `POST /api/v1/purchase-orders/` - Create new purchase order
- `GET /api/v1/purchase-orders/search?query=` - Search purchase orders
- `GET /api/v1/purchase-orders/{id}` - Get purchase order details
- `PUT /api/v1/purchase-orders/{id}` - Update purchase order
- `DELETE /api/v1/purchase-orders/{id}` - Delete purchase order

### Staff Management
- `GET /api/v1/staff/` - List all staff
- `GET /api/v1/staff/active` - List active staff
- `POST /api/v1/staff/` - Create new staff member
- `GET /api/v1/staff/search?query=` - Search staff
- `GET /api/v1/staff/{id}` - Get staff details
- `PUT /api/v1/staff/{id}` - Update staff
- `DELETE /api/v1/staff/{id}` - Delete staff

### Dashboard
- `GET /api/v1/dashboard/stats` - Get dashboard statistics
- `GET /api/v1/dashboard/requisitions-by-type` - Get requisitions by type
- `GET /api/v1/dashboard/supplier-performance` - Get supplier performance metrics
- `GET /api/v1/dashboard/department-metrics` - Get department metrics

### Users
- `GET /api/v1/users/` - List all users
- `POST /api/v1/users/` - Create new user
- `GET /api/v1/users/me` - Get current user
- `GET /api/v1/users/{id}` - Get user details
- `PUT /api/v1/users/{id}` - Update user

### Audit Logs
- `GET /api/v1/audit-logs/` - List audit logs
- `POST /api/v1/audit-logs/` - Create audit log
- `GET /api/v1/audit-logs/user/{user_id}` - Get user audit logs
- `GET /api/v1/audit-logs/table/{table_name}` - Get table audit logs

## Installation

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the application:
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

3. Access the API documentation:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Default Admin User

- Email: admin@procurement.com
- Password: admin123

## Database Schema

The system uses SQLite by default with the following main entities:

- **Users**: System users with role-based access
- **Requisitions**: Procurement requests with items
- **Suppliers**: Vendor information and categories
- **Purchase Orders**: PO management with delivery tracking
- **Staff**: Staff member information and roles
- **Audit Logs**: System activity tracking

## Configuration

Key configuration options in `app/core/config.py`:

- `DATABASE_URL`: Database connection string
- `SECRET_KEY`: JWT signing key
- `ACCESS_TOKEN_EXPIRE_MINUTES`: Token expiration time
- `BACKEND_CORS_ORIGINS`: Allowed CORS origins

## Data Models

### Requisition
- Requisition number, office, type (consumable/non-consumable)
- Purpose, accountable officer, staff in charge
- Items with specifications, quantities, and brands
- Status tracking (pending, approved, completed, etc.)

### Supplier
- Company information, contact details
- TIN, VAT registration
- Categories and status management
- Performance tracking

### Purchase Order
- Links to requisitions and suppliers
- Procurement modes and delivery tracking
- Status management and notes
- Multiple delivery date support

## Security

- JWT-based authentication
- Role-based access control (Admin, Procurement, Requester, Auditor, Viewer)
- Password hashing with bcrypt
- CORS configuration for frontend integration

## API Response Format

All API responses follow a consistent format:

```json
{
  "id": "string",
  "created_at": "datetime",
  "updated_at": "datetime",
  // ... other fields
}
```

Error responses:
```json
{
  "detail": "Error message"
}
```