from sqlalchemy import Column, String, DateTime, Text, Integer, ForeignKey, Enum as SQLEnum
from sqlalchemy.orm import relationship
from enum import Enum
from .base import BaseModel

class RequisitionType(str, Enum):
    CONSUMABLE = "consumable"
    NON_CONSUMABLE = "non_consumable"

class RequisitionStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved" 
    REJECTED = "rejected"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class Requisition(BaseModel):
    __tablename__ = "requisitions"
    
    req_number = Column(String, unique=True, nullable=False, index=True)
    office = Column(String, nullable=False)
    req_type = Column(SQLEnum(RequisitionType), nullable=False)
    date_requested = Column(DateTime, nullable=False)
    date_received = Column(DateTime, nullable=False)
    purpose = Column(Text, nullable=False)
    other_purpose = Column(Text, nullable=True)
    accountable_officer = Column(String, nullable=False)
    staff_in_charge = Column(String, nullable=False)
    status = Column(SQLEnum(RequisitionStatus), default=RequisitionStatus.PENDING)
    description = Column(Text, nullable=True)
    
    # Relationships
    items = relationship("RequisitionItem", back_populates="requisition", cascade="all, delete-orphan")
    purchase_orders = relationship("PurchaseOrder", back_populates="requisition")

class RequisitionItem(BaseModel):
    __tablename__ = "requisition_items"
    
    requisition_id = Column(String, ForeignKey("requisitions.id"), nullable=False)
    item_name = Column(String, nullable=False)
    quantity_unit = Column(String, nullable=False)
    brand_model = Column(String, nullable=True)
    assigned_to = Column(String, nullable=True)
    
    # Relationships
    requisition = relationship("Requisition", back_populates="items")