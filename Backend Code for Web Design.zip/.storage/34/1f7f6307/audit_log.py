from typing import List
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.audit_log import AuditLog
from app.schemas.audit_log import AuditLogCreate, AuditLogCreate

class CRUDAuditLog(CRUDBase[AuditLog, AuditLogCreate, AuditLogCreate]):
    def get_by_user(self, db: Session, *, user_id: str, skip: int = 0, limit: int = 100) -> List[AuditLog]:
        return db.query(AuditLog).filter(AuditLog.user_id == user_id).offset(skip).limit(limit).all()
    
    def get_by_table(self, db: Session, *, table_name: str, skip: int = 0, limit: int = 100) -> List[AuditLog]:
        return db.query(AuditLog).filter(AuditLog.table_name == table_name).offset(skip).limit(limit).all()

audit_log = CRUDAuditLog(AuditLog)