from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api.deps import get_db, get_current_active_user
from app.crud import staff
from app.schemas.staff import Staff, StaffCreate, StaffUpdate
from app.models.user import User

router = APIRouter()

@router.get("/", response_model=List[Staff])
def read_staff(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    staff_members = staff.get_multi(db, skip=skip, limit=limit)
    return staff_members

@router.get("/active", response_model=List[Staff])
def read_active_staff(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    staff_members = staff.get_active_staff(db, skip=skip, limit=limit)
    return staff_members

@router.post("/", response_model=Staff)
def create_staff_member(
    *,
    db: Session = Depends(get_db),
    staff_in: StaffCreate,
    current_user: User = Depends(get_current_active_user),
):
    staff_obj = staff.create(db=db, obj_in=staff_in)
    return staff_obj

@router.get("/search", response_model=List[Staff])
def search_staff(
    query: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    staff_members = staff.search_staff(db, query=query, skip=skip, limit=limit)
    return staff_members

@router.get("/{staff_id}", response_model=Staff)
def read_staff_member(
    *,
    db: Session = Depends(get_db),
    staff_id: str,
    current_user: User = Depends(get_current_active_user),
):
    staff_obj = staff.get(db=db, id=staff_id)
    if not staff_obj:
        raise HTTPException(status_code=404, detail="Staff member not found")
    return staff_obj

@router.put("/{staff_id}", response_model=Staff)
def update_staff_member(
    *,
    db: Session = Depends(get_db),
    staff_id: str,
    staff_in: StaffUpdate,
    current_user: User = Depends(get_current_active_user),
):
    staff_obj = staff.get(db=db, id=staff_id)
    if not staff_obj:
        raise HTTPException(status_code=404, detail="Staff member not found")
    staff_obj = staff.update(db=db, db_obj=staff_obj, obj_in=staff_in)
    return staff_obj

@router.delete("/{staff_id}")
def delete_staff_member(
    *,
    db: Session = Depends(get_db),
    staff_id: str,
    current_user: User = Depends(get_current_active_user),
):
    staff_obj = staff.get(db=db, id=staff_id)
    if not staff_obj:
        raise HTTPException(status_code=404, detail="Staff member not found")
    staff.remove(db=db, id=staff_id)
    return {"message": "Staff member deleted successfully"}