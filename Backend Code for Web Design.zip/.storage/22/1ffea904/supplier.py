from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime
from app.models.supplier import SupplierStatus, SupplierCategory

class SupplierBase(BaseModel):
    supplier_id: Optional[str] = None
    company_name: str
    contact_person: str
    email: str
    phone: str
    tin: Optional[str] = None
    vat: Optional[str] = None
    category: SupplierCategory
    status: SupplierStatus = SupplierStatus.ACTIVE
    address: Optional[str] = None
    notes: Optional[str] = None

class SupplierCreate(SupplierBase):
    @validator('supplier_id', pre=True, always=True)
    def generate_supplier_id(cls, v):
        if not v:
            import time
            return f"SUP-{int(time.time())}"
        return v

class SupplierUpdate(BaseModel):
    company_name: Optional[str] = None
    contact_person: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    tin: Optional[str] = None
    vat: Optional[str] = None
    category: Optional[SupplierCategory] = None
    status: Optional[SupplierStatus] = None
    address: Optional[str] = None
    notes: Optional[str] = None

class Supplier(SupplierBase):
    id: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        orm_mode = True