from pydantic import BaseModel, validator
from typing import List, Optional
from datetime import datetime
from app.models.requisition import RequisitionType, RequisitionStatus

class RequisitionItemBase(BaseModel):
    item_name: str
    quantity_unit: str
    brand_model: Optional[str] = None
    assigned_to: Optional[str] = None

class RequisitionItemCreate(RequisitionItemBase):
    pass

class RequisitionItem(RequisitionItemBase):
    id: str
    requisition_id: str
    created_at: datetime
    
    class Config:
        orm_mode = True

class RequisitionBase(BaseModel):
    req_number: Optional[str] = None
    office: str
    req_type: RequisitionType
    date_requested: datetime
    date_received: datetime
    purpose: str
    other_purpose: Optional[str] = None
    accountable_officer: str
    staff_in_charge: str
    status: RequisitionStatus = RequisitionStatus.PENDING
    description: Optional[str] = None

class RequisitionCreate(RequisitionBase):
    items: List[RequisitionItemCreate]
    
    @validator('req_number', pre=True, always=True)
    def generate_req_number(cls, v):
        if not v:
            import time
            return f"REQ-{int(time.time())}"
        return v

class RequisitionUpdate(BaseModel):
    office: Optional[str] = None
    req_type: Optional[RequisitionType] = None
    date_requested: Optional[datetime] = None
    date_received: Optional[datetime] = None
    purpose: Optional[str] = None
    other_purpose: Optional[str] = None
    accountable_officer: Optional[str] = None
    staff_in_charge: Optional[str] = None
    status: Optional[RequisitionStatus] = None
    description: Optional[str] = None

class Requisition(RequisitionBase):
    id: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    items: List[RequisitionItem] = []
    
    class Config:
        orm_mode = True