from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api.deps import get_db, get_current_active_user
from app.crud import requisition
from app.schemas.requisition import Requisition, RequisitionCreate, RequisitionUpdate
from app.models.user import User

router = APIRouter()

@router.get("/", response_model=List[Requisition])
def read_requisitions(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    requisitions = requisition.get_multi(db, skip=skip, limit=limit)
    return requisitions

@router.post("/", response_model=Requisition)
def create_requisition(
    *,
    db: Session = Depends(get_db),
    requisition_in: RequisitionCreate,
    current_user: User = Depends(get_current_active_user),
):
    requisition_obj = requisition.create_with_items(db=db, obj_in=requisition_in)
    return requisition_obj

@router.get("/search", response_model=List[Requisition])
def search_requisitions(
    query: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    requisitions = requisition.search_requisitions(db, query=query, skip=skip, limit=limit)
    return requisitions

@router.get("/{requisition_id}", response_model=Requisition)
def read_requisition(
    *,
    db: Session = Depends(get_db),
    requisition_id: str,
    current_user: User = Depends(get_current_active_user),
):
    requisition_obj = requisition.get(db=db, id=requisition_id)
    if not requisition_obj:
        raise HTTPException(status_code=404, detail="Requisition not found")
    return requisition_obj

@router.put("/{requisition_id}", response_model=Requisition)
def update_requisition(
    *,
    db: Session = Depends(get_db),
    requisition_id: str,
    requisition_in: RequisitionUpdate,
    current_user: User = Depends(get_current_active_user),
):
    requisition_obj = requisition.get(db=db, id=requisition_id)
    if not requisition_obj:
        raise HTTPException(status_code=404, detail="Requisition not found")
    requisition_obj = requisition.update(db=db, db_obj=requisition_obj, obj_in=requisition_in)
    return requisition_obj

@router.delete("/{requisition_id}")
def delete_requisition(
    *,
    db: Session = Depends(get_db),
    requisition_id: str,
    current_user: User = Depends(get_current_active_user),
):
    requisition_obj = requisition.get(db=db, id=requisition_id)
    if not requisition_obj:
        raise HTTPException(status_code=404, detail="Requisition not found")
    requisition.remove(db=db, id=requisition_id)
    return {"message": "Requisition deleted successfully"}