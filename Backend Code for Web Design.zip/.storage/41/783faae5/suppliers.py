from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api.deps import get_db, get_current_active_user
from app.crud import supplier
from app.schemas.supplier import Supplier, SupplierCreate, SupplierUpdate
from app.models.user import User

router = APIRouter()

@router.get("/", response_model=List[Supplier])
def read_suppliers(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    suppliers = supplier.get_multi(db, skip=skip, limit=limit)
    return suppliers

@router.get("/active", response_model=List[Supplier])
def read_active_suppliers(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    suppliers = supplier.get_active_suppliers(db, skip=skip, limit=limit)
    return suppliers

@router.post("/", response_model=Supplier)
def create_supplier(
    *,
    db: Session = Depends(get_db),
    supplier_in: SupplierCreate,
    current_user: User = Depends(get_current_active_user),
):
    supplier_obj = supplier.create(db=db, obj_in=supplier_in)
    return supplier_obj

@router.get("/search", response_model=List[Supplier])
def search_suppliers(
    query: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    suppliers = supplier.search_suppliers(db, query=query, skip=skip, limit=limit)
    return suppliers

@router.get("/{supplier_id}", response_model=Supplier)
def read_supplier(
    *,
    db: Session = Depends(get_db),
    supplier_id: str,
    current_user: User = Depends(get_current_active_user),
):
    supplier_obj = supplier.get(db=db, id=supplier_id)
    if not supplier_obj:
        raise HTTPException(status_code=404, detail="Supplier not found")
    return supplier_obj

@router.put("/{supplier_id}", response_model=Supplier)
def update_supplier(
    *,
    db: Session = Depends(get_db),
    supplier_id: str,
    supplier_in: SupplierUpdate,
    current_user: User = Depends(get_current_active_user),
):
    supplier_obj = supplier.get(db=db, id=supplier_id)
    if not supplier_obj:
        raise HTTPException(status_code=404, detail="Supplier not found")
    supplier_obj = supplier.update(db=db, db_obj=supplier_obj, obj_in=supplier_in)
    return supplier_obj

@router.delete("/{supplier_id}")
def delete_supplier(
    *,
    db: Session = Depends(get_db),
    supplier_id: str,
    current_user: User = Depends(get_current_active_user),
):
    supplier_obj = supplier.get(db=db, id=supplier_id)
    if not supplier_obj:
        raise HTTPException(status_code=404, detail="Supplier not found")
    supplier.remove(db=db, id=supplier_id)
    return {"message": "Supplier deleted successfully"}