from typing import List, Optional
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.staff import Staff
from app.schemas.staff import StaffCreate, StaffUpdate

class CRUDStaff(CRUDBase[Staff, StaffCreate, StaffUpdate]):
    def get_by_staff_id(self, db: Session, *, staff_id: str) -> Optional[Staff]:
        return db.query(Staff).filter(Staff.staff_id == staff_id).first()
    
    def get_by_email(self, db: Session, *, email: str) -> Optional[Staff]:
        return db.query(Staff).filter(Staff.email == email).first()
    
    def search_staff(self, db: Session, *, query: str, skip: int = 0, limit: int = 100) -> List[Staff]:
        return db.query(Staff).filter(
            Staff.name.contains(query) |
            Staff.email.contains(query) |
            Staff.department.contains(query)
        ).offset(skip).limit(limit).all()
    
    def get_active_staff(self, db: Session, skip: int = 0, limit: int = 100) -> List[Staff]:
        return db.query(Staff).filter(Staff.is_active == "active").offset(skip).limit(limit).all()

staff = CRUDStaff(Staff)