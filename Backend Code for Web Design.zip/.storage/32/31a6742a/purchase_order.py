from typing import List, Optional
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.purchase_order import PurchaseOrder, DeliveryDate
from app.schemas.purchase_order import PurchaseOrderCreate, PurchaseOrderUpdate

class CRUDPurchaseOrder(CRUDBase[PurchaseOrder, PurchaseOrderCreate, PurchaseOrderUpdate]):
    def create_with_delivery_dates(self, db: Session, *, obj_in: PurchaseOrderCreate) -> PurchaseOrder:
        # Create purchase order
        po_data = obj_in.dict(exclude={"delivery_dates"})
        db_po = PurchaseOrder(**po_data)
        db.add(db_po)
        db.flush()  # To get the ID
        
        # Create delivery dates
        for delivery_data in obj_in.delivery_dates:
            db_delivery = DeliveryDate(**delivery_data.dict(), purchase_order_id=db_po.id)
            db.add(db_delivery)
        
        db.commit()
        db.refresh(db_po)
        return db_po
    
    def get_by_po_number(self, db: Session, *, po_number: str) -> Optional[PurchaseOrder]:
        return db.query(PurchaseOrder).filter(PurchaseOrder.po_number == po_number).first()
    
    def search_purchase_orders(self, db: Session, *, query: str, skip: int = 0, limit: int = 100) -> List[PurchaseOrder]:
        return db.query(PurchaseOrder).filter(
            PurchaseOrder.po_number.contains(query) |
            PurchaseOrder.supplier_name.contains(query) |
            PurchaseOrder.department.contains(query)
        ).offset(skip).limit(limit).all()

purchase_order = CRUDPurchaseOrder(PurchaseOrder)