from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.api.deps import get_db, get_current_active_user
from app.crud import audit_log
from app.schemas.audit_log import AuditLog, AuditLogCreate
from app.models.user import User

router = APIRouter()

@router.get("/", response_model=List[AuditLog])
def read_audit_logs(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    audit_logs = audit_log.get_multi(db, skip=skip, limit=limit)
    return audit_logs

@router.post("/", response_model=AuditLog)
def create_audit_log(
    *,
    db: Session = Depends(get_db),
    audit_log_in: AuditLogCreate,
    current_user: User = Depends(get_current_active_user),
):
    audit_log_obj = audit_log.create(db=db, obj_in=audit_log_in)
    return audit_log_obj

@router.get("/user/{user_id}", response_model=List[AuditLog])
def read_user_audit_logs(
    user_id: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    audit_logs = audit_log.get_by_user(db, user_id=user_id, skip=skip, limit=limit)
    return audit_logs

@router.get("/table/{table_name}", response_model=List[AuditLog])
def read_table_audit_logs(
    table_name: str,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user),
):
    audit_logs = audit_log.get_by_table(db, table_name=table_name, skip=skip, limit=limit)
    return audit_logs