from typing import List, Optional
from sqlalchemy.orm import Session
from app.crud.base import CRUDBase
from app.models.supplier import Supplier
from app.schemas.supplier import SupplierCreate, SupplierUpdate

class CRUDSupplier(CRUDBase[Supplier, SupplierCreate, SupplierUpdate]):
    def get_by_supplier_id(self, db: Session, *, supplier_id: str) -> Optional[Supplier]:
        return db.query(Supplier).filter(Supplier.supplier_id == supplier_id).first()
    
    def search_suppliers(self, db: Session, *, query: str, skip: int = 0, limit: int = 100) -> List[Supplier]:
        return db.query(Supplier).filter(
            Supplier.company_name.contains(query) |
            Supplier.contact_person.contains(query) |
            Supplier.supplier_id.contains(query)
        ).offset(skip).limit(limit).all()
    
    def get_active_suppliers(self, db: Session, skip: int = 0, limit: int = 100) -> List[Supplier]:
        return db.query(Supplier).filter(Supplier.status == "active").offset(skip).limit(limit).all()

supplier = CRUDSupplier(Supplier)