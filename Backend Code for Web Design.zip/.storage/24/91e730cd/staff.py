from pydantic import BaseModel, validator
from typing import Optional
from datetime import datetime
from app.models.staff import StaffPosition

class StaffBase(BaseModel):
    staff_id: Optional[str] = None
    name: str
    email: str
    phone: Optional[str] = None
    department: str
    position: StaffPosition
    is_active: str = "active"

class StaffCreate(StaffBase):
    @validator('staff_id', pre=True, always=True)
    def generate_staff_id(cls, v):
        if not v:
            import time
            return f"STAFF-{int(time.time())}"
        return v

class StaffUpdate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    department: Optional[str] = None
    position: Optional[StaffPosition] = None
    is_active: Optional[str] = None

class Staff(StaffBase):
    id: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    class Config:
        orm_mode = True